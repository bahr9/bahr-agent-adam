#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_exceptions.py -- StageError Contract Enforcement
=====================================================
بيدور على كل "except Exception" في الملفات الجوهرية
ويتأكد انها بترفع StageError مش بتبلعها صامت.

الاستخدام:
    python check_exceptions.py              # يفحص CORE_FILES
    python check_exceptions.py --all        # يفحص كل الـ .py files

Exit codes:
    0 = كل حاجة تمام
    1 = في violations

مناسب يتضاف كـ pre-commit hook:
    # .git/hooks/pre-commit
    python check_exceptions.py || exit 1
"""

import ast
import os
import sys
from pathlib import Path
from typing import Optional

# ============================================================
# الملفات الجوهرية
# ============================================================

CORE_FILES = [
    "executive_brain.py",
    "adam_runtime.py",
    "adam_mind.py",
]

# ============================================================
# Allowlists -- (filename, class, function)
#
# BOUNDARY_FUNCTIONS:
#   Runtime boundary -- بيمسك exception ويحوّله لـ user-facing string
#   مسموح بـ logger.error + return string بدون raise
#
# NON_CRITICAL_FUNCTIONS:
#   Non-critical stages -- فشلهم مش المفروض يوقف الـ pipeline
#   مسموح بـ logger.warning بدون raise
#
# ملاحظة: run_scheduled مش في الـ allowlist لأنه بيعمل raise --
#   لو حد غيّره لـ return None مستقبلاً، الـchecker هيمسكه فوراً.
# ============================================================

BOUNDARY_FUNCTIONS = {
    ("adam_runtime.py", "AdamRuntime", "run"),
}

NON_CRITICAL_FUNCTIONS = {
    ("executive_brain.py", "ExecutiveBrain", "_stage_learn"),
    ("adam_mind.py",       "AdamMind",       "_deep_analyze"),
}


# ============================================================
# ExceptionChecker -- AST Visitor
# ============================================================

class ExceptionChecker(ast.NodeVisitor):
    """
    بيتتبع:
        self._current_class    -- اسم الـ class الحالي
        self._current_function -- اسم الدالة الحالية

    بيقارن (filename, class, function) مش اسم الدالة بس.
    """

    def __init__(self, filename: str):
        self.filename         = os.path.basename(filename)
        self.violations       = []
        self._current_class   = None
        self._current_function= None

    # ----------------------------------------------------------------
    # Class tracking
    # ----------------------------------------------------------------

    def visit_ClassDef(self, node: ast.ClassDef):
        old = self._current_class
        self._current_class = node.name
        self.generic_visit(node)
        self._current_class = old

    # ----------------------------------------------------------------
    # Function tracking
    # ----------------------------------------------------------------

    def visit_FunctionDef(self, node: ast.FunctionDef):
        old = self._current_function
        self._current_function = node.name
        self.generic_visit(node)
        self._current_function = old

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        old = self._current_function
        self._current_function = node.name
        self.generic_visit(node)
        self._current_function = old

    # ----------------------------------------------------------------
    # Exception handling check
    # ----------------------------------------------------------------

    def visit_ExceptHandler(self, node: ast.ExceptHandler):
        if not self._is_broad_catch(node):
            self.generic_visit(node)
            return

        violation = self._check_body(node)
        if violation:
            self.violations.append({
                "file":     self.filename,
                "class":    self._current_class or "(module)",
                "function": self._current_function or "(module)",
                "line":     node.lineno,
                "issue":    violation,
            })

        self.generic_visit(node)

    # ----------------------------------------------------------------
    # Helpers
    # ----------------------------------------------------------------

    def _is_broad_catch(self, node: ast.ExceptHandler) -> bool:
        """هل الـ handler بيمسك Exception العامة؟"""
        if node.type is None:
            return True
        if isinstance(node.type, ast.Name):
            return node.type.id in ("Exception", "BaseException")
        return False

    def _location(self) -> tuple:
        return (
            self.filename,
            self._current_class   or "",
            self._current_function or "",
        )

    def _check_body(self, node: ast.ExceptHandler) -> Optional[str]:
        """
        بيرجع وصف المشكلة لو في violation.
        None لو مقبول.
        """
        loc = self._location()
        fn  = self._current_function or "?"
        cls = self._current_class    or "?"

        # ----------------------------------------------------------------
        # BOUNDARY: لازم logger.error(...) + return <string>
        # return 123 او return None -> violation
        # ----------------------------------------------------------------
        if loc in BOUNDARY_FUNCTIONS:
            has_error  = self._has_logger_call(node, "error")
            has_str_return = self._has_string_return(node)
            if has_error and has_str_return:
                return None
            missing = []
            if not has_error:
                missing.append("logger.error(...)")
            if not has_str_return:
                missing.append("return <string>")
            return "Boundary [" + cls + "." + fn + "] محتاج: " + " + ".join(missing)

        # ----------------------------------------------------------------
        # NON-CRITICAL: لازم logger.warning(...) فعلي -- مش variable بالاسم ده
        # ----------------------------------------------------------------
        if loc in NON_CRITICAL_FUNCTIONS:
            if self._has_logger_call(node, "warning"):
                return None
            return "Non-critical [" + cls + "." + fn + "] محتاج logger.warning(...) حقيقي"

        # ----------------------------------------------------------------
        # كل دالة تانية: لازم raise
        # ----------------------------------------------------------------
        if self._has_raise(node):
            return None

        has_logger = self._has_logger_call(node, None)
        note = " -- هل المفروض تكون في NON_CRITICAL_FUNCTIONS?" if has_logger else ""
        return "except Exception في [" + cls + "." + fn + "] بدون raise StageError" + note

    # ----------------------------------------------------------------
    # AST Helpers -- بيدوروا على nodes حقيقية مش text
    # ----------------------------------------------------------------

    def _has_raise(self, node: ast.ExceptHandler) -> bool:
        """هل في raise statement في الـ body؟"""
        for stmt in ast.walk(ast.Module(body=node.body, type_ignores=[])):
            if isinstance(stmt, ast.Raise):
                return True
        return False

    def _has_logger_call(self, node: ast.ExceptHandler, method: Optional[str]) -> bool:
        """
        هل في استدعاء logger.<method>(...) حقيقي بالـ AST؟
        method=None -> أي logger call
        بيرفض: logger_name = "x" / warning = "y" (مش calls حقيقية)
        """
        for item in ast.walk(ast.Module(body=node.body, type_ignores=[])):
            if not isinstance(item, ast.Call):
                continue
            func = item.func
            if not isinstance(func, ast.Attribute):
                continue
            if not isinstance(func.value, ast.Name):
                continue
            if func.value.id != "logger":
                continue
            if method is None or func.attr == method:
                return True
        return False

    def _has_string_return(self, node: ast.ExceptHandler) -> bool:
        """
        هل في return بيرجع string؟
        مقبول:   string literal, f-string, variable, function call, binary op
        مرفوض:   return None / return 123 / return False / return بدون قيمة
        """
        for stmt in node.body:
            if not isinstance(stmt, ast.Return):
                continue
            val = stmt.value
            if val is None:
                continue
            if isinstance(val, ast.Constant):
                if isinstance(val.value, str) and val.value:
                    return True
                continue  # return 123, return None, return False
            if isinstance(val, (ast.JoinedStr, ast.Name, ast.Call, ast.BinOp, ast.IfExp)):
                return True
        return False


# ============================================================
# check_file
# ============================================================

def check_file(filepath: str) -> list:
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            source = f.read()
        tree    = ast.parse(source, filename=filepath)
        checker = ExceptionChecker(filepath)
        checker.visit(tree)
        return checker.violations
    except SyntaxError as e:
        return [{"file": filepath, "class": "?", "function": "?",
                 "line": e.lineno, "issue": "Syntax error: " + str(e)}]
    except Exception as e:
        return [{"file": filepath, "class": "?", "function": "?",
                 "line": 0, "issue": "فشل الفحص: " + str(e)}]


# ============================================================
# main
# ============================================================

def main():
    check_all = "--all" in sys.argv

    if check_all:
        all_py = list(Path(".").rglob("*.py"))
        files  = [str(f) for f in all_py if "__pycache__" not in str(f)]
    else:
        files = [f for f in CORE_FILES if os.path.exists(f)]

    if not files:
        print("مفيش ملفات للفحص.")
        return 0

    all_violations = []
    for fp in files:
        all_violations.extend(check_file(fp))

    print("=" * 50)
    print("StageError Contract Check")
    print("=" * 50)
    print("فحصت: " + str(len(files)) + " ملف")

    if not all_violations:
        print("كل حاجة تمام -- مفيش violations")
        return 0

    print("Violations: " + str(len(all_violations)))
    print("-" * 50)
    for v in all_violations:
        print("FILE:     " + v["file"])
        print("CLASS:    " + v.get("class", "?"))
        print("FUNCTION: " + v.get("function", "?"))
        print("LINE:     " + str(v["line"]))
        print("ISSUE:    " + v["issue"])
        print()

    return 1


if __name__ == "__main__":
    sys.exit(main())
